﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace ConnectedDemo
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static string connectionstring = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
        SqlConnection connection = new SqlConnection(connectionstring);
        SqlCommand command;
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            GetProductsCount();
            DisplayData();
        }
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            AddStudentDetails();
            DisplayData();
            ClearData();
        }
        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchStudentDetails();    
        }
        private void btnUpdate_click(object sender, RoutedEventArgs e)
        {
            UpdateStudentDetails();
            DisplayData();
            ClearData();
        }
        private void btnDelete_click(object sender, RoutedEventArgs e)
        {
            DeleteStudentDetails();
            DisplayData();
            ClearData();
        }
        public void DisplayData()
        {
            connection = new SqlConnection(connectionstring);
            SqlDataReader dataReader;
            try
            {
                string newQuery = "SELECT * FROM Student_Master";
                command = new SqlCommand(newQuery, connection);
                connection.Open();
                dataReader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(dataReader);
                dgStudent.DataContext = dataTable;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
            finally
            {
                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        private void AddStudentDetails()
        {
            try
            {
                Student student = new Student();
                student.StudentCode = Convert.ToInt32(txtStudentCode.Text);
                student.StudentName = txtStudentName.Text;
                student.DepartmentCode = Convert.ToInt32(txtDepartmentCode.Text);
                student.DateOfBirth = Convert.ToDateTime(txtDateOfBirth.Text);
                student.Address = txtAddress.Text;
                string newQuery = "INSERT INTO Student_Master(Stud_Code, Stud_Name, Dept_Code, Stud_Dob, Address) VALUES(" + txtStudentCode.Text + ",'" + txtStudentName.Text+ "'," + txtDepartmentCode.Text + "," + txtDateOfBirth.Text + ",'" + txtAddress.Text + "')";
                command = new SqlCommand(newQuery, connection);
                connection.Open();
                int recordsAffected = command.ExecuteNonQuery();
                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record added successfully");    
                }
                else
                    MessageBox.Show("Record not added");
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Error occured" + exception.Message);
            }
            finally
            {
                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        private void GetProductsCount()
        {
            try
            {
                string newQuery = "SELECT Count(Stud_Code) from Student_Master";
                command = new SqlCommand(newQuery, connection);
                connection.Open();
                int studentcount = (int)command.ExecuteScalar();
                MessageBox.Show(studentcount + " students found");

            }
            catch (Exception exception)
            {
                MessageBox.Show("Exception Occured: " + exception.Message);
            }
            finally
            {
                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        private void SearchStudentDetails()
        {
            SqlDataReader dataReader;
            try
            {
                string newQuery = "SELECT * FROM Student_Master WHERE Stud_Code=" + int.Parse(txtStudentCode.Text);
                command = new SqlCommand(newQuery, connection);
                connection.Open();
                dataReader = command.ExecuteReader();
                while (dataReader.Read())
                {
                    txtStudentName.Text = dataReader["Stud_Name"].ToString();
                    txtDepartmentCode.Text = dataReader["Dept_Code"].ToString();
                    txtDateOfBirth.Text = dataReader["Stud_Dob"].ToString();
                    txtAddress.Text = dataReader["Address"].ToString();
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
            finally
            {
                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        private void UpdateStudentDetails()
        {
            try
            {
                string newQuery = "UPDATE Student_Master SET Stud_Name='" + txtStudentName.Text + "',Dept_Code='" + int.Parse(txtDepartmentCode.Text) + "',Address='" + txtAddress.Text + "' WHERE Stud_Code=" + int.Parse(txtStudentCode.Text);
                command = new SqlCommand(newQuery, connection);
                connection.Open();
                int recordsUpdated =command.ExecuteNonQuery();
                if (recordsUpdated > 0)
                {
                    MessageBox.Show("Record Updated successfully");
                }
                else
                    MessageBox.Show("Error in Updating Information!!");
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
            finally
            {
                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        private void DeleteStudentDetails()
        {
            try
            {
                string newQuery = "DELETE FROM Student_Master WHERE Stud_Code=" + int.Parse(txtStudentCode.Text);
                command = new SqlCommand(newQuery, connection);
                connection.Open();
                int recordsDeleted = command.ExecuteNonQuery();
                if (recordsDeleted > 0)
                {
                    MessageBox.Show("Record Deleted successfully");      
                }
                else
                    MessageBox.Show("Error in Deleting Information!!");
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception.Message);
            }
            finally
            {
                command.Dispose();
                if (connection.State == ConnectionState.Open)
                    connection.Close();
            }
        }
        public void ClearData()
        {
            txtStudentCode.Text = "";
            txtStudentName.Text = "";
            txtDepartmentCode.Text = "";
            txtDateOfBirth.Text = "";
            txtAddress.Text = "";
        }
    }
}
