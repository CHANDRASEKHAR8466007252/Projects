﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConnectedDemo
{
    public class Student
    {
        public int StudentCode { get; set; }
        public string StudentName { get; set; }
        public int DepartmentCode { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string Address { get; set; }
    }
}
