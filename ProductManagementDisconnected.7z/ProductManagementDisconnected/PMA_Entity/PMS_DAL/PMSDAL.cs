﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMA_Entity;
using PMS_Exception;
using System.Data;
using System.Data.SqlClient;


namespace PMS_DAL
{
    public class PMSDAL
    {
        SqlConnection sqlConnection = new SqlConnection(Config.ConnectionString);
        SqlCommand sqlCommand = new SqlCommand();
        public bool AddProductDAL(Product newProduct)
        {
            bool isProductAdded = false;
            try
            {
                sqlConnection.Open();
                sqlCommand.CommandText = "AddProduct_46023355";
                sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@ProductId", newProduct.ProductId);
                sqlCommand.Parameters.AddWithValue("@ProductName", newProduct.ProductName);
                sqlCommand.Parameters.AddWithValue("@Price", newProduct.Price);
                sqlCommand.Parameters.AddWithValue("@Quantity", newProduct.Quantity);

                SqlParameter outParameter = new SqlParameter();
                outParameter.ParameterName = "isAdded";
                outParameter.SqlDbType = SqlDbType.Int;
                outParameter.Direction = ParameterDirection.Output;
                sqlCommand.Parameters.Add(outParameter);

                sqlCommand.Connection = sqlConnection;
                sqlCommand.ExecuteNonQuery();
                if(int.Parse(outParameter.Value.ToString())==1)
                {
                    isProductAdded = true; 
                }
            }
            catch(SqlException exception)
            {
                throw new ProductException(exception.Message);
            }
            finally
            {
                sqlCommand.Dispose();
                if (sqlConnection.State ==ConnectionState.Open)
                    sqlConnection.Close();
            }
            return isProductAdded;
        }
    }
}
