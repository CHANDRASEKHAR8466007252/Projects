﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PMS_DAL
{
    static class Config
    {
        public static string ConnectionString = @"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_23Jan20_Pune;User ID=sqluser;Password=sqluser";
    }
}
