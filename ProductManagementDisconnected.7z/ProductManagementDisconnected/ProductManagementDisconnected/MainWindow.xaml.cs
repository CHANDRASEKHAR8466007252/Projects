﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ProductManagementDisconnected
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        SqlConnection sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString);
        SqlCommand sqlCommand = new SqlCommand();
        DataSet dataSet = new DataSet();
        SqlDataAdapter sqlDataAdapter;
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Window_Loaded(object sender, EventArgs e)
        {
            DisplayProductDetails();
        }
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            AddProductDetails();
            DisplayProductDetails();
            ClearData();
        }
        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            SearchProductdetails();

        }
        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            UpdateProductDetails();
            DisplayProductDetails();
            ClearData();
        }
        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            DeleteProductDetails();
            DisplayProductDetails();
            ClearData();
        }
        private void btnWriteToDatabase_Click(object sender, RoutedEventArgs e)
        {
            SqlCommandBuilder sqlCommandBuilder = new SqlCommandBuilder(sqlDataAdapter);
            sqlDataAdapter.UpdateCommand = sqlCommandBuilder.GetUpdateCommand();
            sqlDataAdapter.DeleteCommand = sqlCommandBuilder.GetDeleteCommand();
            sqlDataAdapter.Update(dataSet);
            MessageBox.Show("All Changes Written to Database");
        }
        private void DisplayProductDetails()
        {
            try
            {
                sqlCommand.CommandText = "SELECT * FROM Product_List";
                sqlDataAdapter = new SqlDataAdapter(sqlCommand.CommandText, sqlConnection);
                sqlDataAdapter.Fill(dataSet);
                dgProducts.DataContext = dataSet.Tables[0];
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Occured" + exception.Message);
            }
        }
        private void AddProductDetails()
        {
            try
            {
                DataRow newRow = dataSet.Tables[0].NewRow();
                newRow[0] = txtProductId.Text;
                newRow[1] = txtProductName.Text;
                newRow[2] = txtPrice.Text;
                newRow[3] = txtQuantity.Text;

                dataSet.Tables[0].Rows.Add(newRow);
                MessageBox.Show("Product Added to Dataset");
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Occured" + exception.Message);
            }
        }
        private void SearchProductdetails()
        {
            try
            {
                int ProductId = int.Parse(txtProductId.Text);
                for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
                {
                    int currentRowProductId = int.Parse(dataSet.Tables[0].Rows[i][0].ToString());
                    if (currentRowProductId == ProductId)
                    {
                        MessageBox.Show("Product Found");
                        txtProductName.Text = dataSet.Tables[0].Rows[i][1].ToString();
                        txtPrice.Text = dataSet.Tables[0].Rows[i][2].ToString();
                        txtQuantity.Text = dataSet.Tables[0].Rows[i][3].ToString();
                        break;
                    }
                }
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Occured" + exception.Message);
            }
        }
        private void UpdateProductDetails()
        {
            try
            {
                int ProductId = int.Parse(txtProductId.Text);
                string productName = txtProductName.Text;
                float price = float.Parse(txtPrice.Text);
                int quantity = int.Parse(txtQuantity.Text);
                for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
                {
                    int currentRowProductId = int.Parse(dataSet.Tables[0].Rows[i][0].ToString());
                    if (currentRowProductId == ProductId)
                    {
                        dataSet.Tables[0].Rows[i][1] = txtProductName.Text;
                        dataSet.Tables[0].Rows[i][2] = txtPrice.Text;
                        dataSet.Tables[0].Rows[i][3] = txtQuantity.Text;
                        MessageBox.Show("Data Updated Succesfully");
                        break;
                    }
                }
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Occured" + exception.Message);
            }
        }
        private void DeleteProductDetails()
        {
            try
            {
                int ProductId = int.Parse(txtProductId.Text);
                for (int i = 0; i < dataSet.Tables[0].Rows.Count; i++)
                {
                    int currentRowProductId = int.Parse(dataSet.Tables[0].Rows[i][0].ToString());
                    if (currentRowProductId == ProductId)
                    {
                        dataSet.Tables[0].Rows.Remove(dataSet.Tables[0].Rows[i]);
                        txtProductName.Text = "";
                        txtPrice.Text = "";
                        txtQuantity.Text = "";
                        break;
                    }
                }
            }
            catch (SqlException exception)
            {
                MessageBox.Show("Exception Occured" + exception.Message);
            }
        }
        public void ClearData()
        {
            txtProductId.Text = "";
            txtProductName.Text = "";
            txtPrice.Text = "";
            txtQuantity.Text = "";            
        }
    }
}
